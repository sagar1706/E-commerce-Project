import React, { useState } from "react";
import { Link } from "react-router-dom";
import {MapPin, X}from "lucide-react"

const Navbar = () => {
   
  const [open, setOpen] = useState(false); // Added state for mobile menu toggle
  const [location, setLocation] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [detecting, setDetecting] = useState(false);

  // Detect user's current location
  const handleDetectLocation = () => {
    setDetecting(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          // You could also reverse geocode this using an API like OpenCage or Google Maps
          setLocation(`Lat: ${latitude.toFixed(2)}, Lng: ${longitude.toFixed(2)}`);
          setDetecting(false);
          setShowModal(false);
        },
        () => {
          alert("Unable to retrieve your location.");
          setDetecting(false);
        }
      );
    } else {
      alert("Geolocation is not supported by your browser.");
      setDetecting(false);
    }
  };

  return (
   <nav className="bg-white py-2 shadow-2xl">
  <div className="max-w-6xl mx-auto flex justify-between items-center px-4">
    {/* Logo Section */}
    <Link to={"/"}>
  <div className="flex items-center gap-5 mr-10">
    {/* Logo text */}
    <h1 className="text-3xl font-extrabold tracking-tight flex items-center">
      <span className="text-indigo-900 hover:text-indigo-600 transition-colors duration-300">
        Go
      </span>
      <span className="text-indigo-800 hover:text-indigo-500 transition-colors duration-300 font-semibold">
        Cart
      </span>
    </h1>

    {/* Location section */}
    <div className="flex items-center gap-1"
    onClick={() => setShowModal(true)}>
      <MapPin className="text-indigo-600 w-5 h-5 hover:text-indigo-400 transition-colors duration-300" />
      <span className="font-medium text-gray-700 hover:text-indigo-600 transition-colors duration-300">
        {location ? location : "Add Address"}
      </span>
    </div>
  </div>
</Link>

{showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-2xl shadow-xl w-80 relative">
            {/* Close button */}
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-3 right-3 text-gray-500 hover:text-gray-700"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-semibold mb-4 text-indigo-800">
              Set Your Location
            </h2>

            <input
              type="text"
              placeholder="Enter your address..."
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full border border-gray-300 rounded-md px-3 py-2 mb-4 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />

            <button
              onClick={handleDetectLocation}
              disabled={detecting}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 rounded-md transition-colors duration-300"
            >
              {detecting ? "Detecting..." : "Detect My Location"}
            </button>
          </div>
        </div>
      )}

{/* Search Input */}
         <div className="hidden lg:flex items-center text-sm gap-2 border border-gray-300 px-3 rounded-full w-96">
  <input
    className="py-1.5 w-full bg-transparent outline-none placeholder-gray-500"
    type="text"
    placeholder="Search products"
  />
            <svg
              width="16"
              height="16"
              viewBox="0 0 16 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M10.836 10.615 15 14.695"
                stroke="#7A7B7D"
                strokeWidth="1.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                clipRule="evenodd"
                d="M9.141 11.738c2.729-1.136 4.001-4.224 2.841-6.898S7.67.921 4.942 2.057C2.211 3.193.94 6.281 2.1 8.955s4.312 3.92 7.041 2.783"
                stroke="#7A7B7D"
                strokeWidth="1.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>

        {/* Desktop Menu */}
        <div className="hidden sm:flex items-center gap-8">
          <a href="/" className="hover:text-indigo-500 transition-colors">Home</a>
          <a href="/about" className="hover:text-indigo-500 transition-colors">About</a>
          <a href="/contact" className="hover:text-indigo-500 transition-colors">Contact</a>

          

          {/* Cart Icon */}
          <Link to={"/carts"}>
          <div className="relative cursor-pointer">
            <svg
              width="18"
              height="18"
              viewBox="0 0 14 14"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M.583.583h2.333l1.564 7.81a1.17 1.17 0 0 0 1.166.94h5.67a1.17 1.17 0 0 0 1.167-.94l.933-4.893H3.5m2.333 8.75a.583.583 0 1 1-1.167 0 .583.583 0 0 1 1.167 0m6.417 0a.583.583 0 1 1-1.167 0 .583.583 0 0 1 1.167 0"
                stroke="#615fff"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <button className="absolute -top-2 -right-3 text-xs text-white bg-indigo-500 w-[18px] h-[18px] rounded-full">
                
              1
            </button>
          </div>
          </Link>

          {/* Login Button */}
          <button className="cursor-pointer px-8 py-2 bg-indigo-500 hover:bg-indigo-600 transition text-white rounded-full">
            Login
          </button>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setOpen(!open)}
          aria-label="Menu"
          className="sm:hidden focus:outline-none"
        >
          <svg
            width="21"
            height="15"
            viewBox="0 0 21 15"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <rect width="21" height="1.5" rx=".75" fill="#426287" />
            <rect x="0" y="6" width="21" height="1.5" rx=".75" fill="#426287" />
            <rect x="0" y="13" width="21" height="1.5" rx=".75" fill="#426287" />
          </svg>
        </button>
      </div>

      {/* Mobile Menu */}
      <div
        className={`sm:hidden ${open ? "flex" : "hidden"} flex-col gap-2 px-5 py-4 bg-white shadow-md`}
      >
        <a href="/" className="block hover:text-indigo-500 transition-colors">
          Home
        </a>
        <a href="/about" className="block hover:text-indigo-500 transition-colors">
          About
        </a>
        <a href="/contact" className="block hover:text-indigo-500 transition-colors">
          Contact
        </a>
        <button className="cursor-pointer px-6 py-2 mt-2 bg-indigo-500 hover:bg-indigo-600 transition text-white rounded-full text-sm">
          Login
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
