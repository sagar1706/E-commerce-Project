import React from 'react'

const Cart = () => {
  return (
    <div>
      Carts
    </div>
  )
}

export default Cart
