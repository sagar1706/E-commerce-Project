import React from 'react'

const About = () => {
  return (
    <div>
      Accout
    </div>
  )
}

export default About
